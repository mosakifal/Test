﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CheckoutClient.DataTransferObjects;
using CheckoutService;

namespace BrighthrTest 
{
    public partial class FormOrder : Form 
        {
        public FormOrder()
        {
            InitializeComponent();
        }

        List<Product> productList = new List<Product>();
            ListViewItem lv = new ListViewItem();
        DataAccess da; 

        private void FormOrder_Load(object sender, EventArgs e)
        {
            da = new DataAccess();
            LoadProductsList();
            SetListViewItem();
        }

        private void SetListViewItem()
        {
            CartListView.View = View.Details;
            CartListView.Columns.Add("Sku", 100, HorizontalAlignment.Left);
            CartListView.Columns.Add("Product name", 175, HorizontalAlignment.Left);
            CartListView.Columns.Add("Price", 120, HorizontalAlignment.Left);
            CartListView.Columns.Add("Quantity", 100, HorizontalAlignment.Left);
            CartListView.Columns.Add("Sub total", 125, HorizontalAlignment.Left);
            LbTotal.Text = "0";
            LbChange.Text = "0";
        }

        public List<Product> LoadProductsList() 
        {
            productList = da.GetProductList();
            CbProduct.ValueMember = "Sku";
            CbProduct.DisplayMember = "Description";
            CbProduct.DataSource = productList;
            return productList;
        }

        private void CbProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
             Product _prodItem = null;

            String _Id = "";
            if(this.CbProduct.SelectedValue != null)
            {
                _prodItem = (Product)this.CbProduct.SelectedItem;
            }
            if(_prodItem != null){
                _Id = _prodItem.Sku;
            }
            TxtPrice.Text = productList.FirstOrDefault(x => x.Sku == _Id)?.Price.ToString();
        }

        
        private void BtnAddToCart_Click(object sender, EventArgs e)
        {
            Product _prodItem = (Product)this.CbProduct.SelectedItem;
           
            lv = CartListView.Items.Add(_prodItem.Sku);
            lv.SubItems.Add(CbProduct.Text);
            lv.SubItems.Add(TxtPrice.Text);
            lv.SubItems.Add(Quantity.Value.ToString());
            lv.SubItems.Add((Convert.ToDouble(TxtPrice.Text) * Convert.ToDouble(Quantity.Value)).ToString());

            List<ProductItem> basket = GetProductListFromCart();

            ICheckout ckeckout = new Checkout();
            double totalPrice = ckeckout.GetTotalPrice((basket));

            LbTotal.Text = (totalPrice).ToString();
            Quantity.Value = 1;

        }

        private List<ProductItem> GetProductListFromCart()
        {
            List<ProductItem> productList = new List<ProductItem>();
            for (int i = 0; i < CartListView.Items.Count; i++)
            {
                int quantity = Convert.ToInt32(CartListView.Items[i].SubItems[3].Text);
                for (int j = 1; j <= quantity; j++)
                {
                    ProductItem p = new ProductItem();
                    p.Sku = CartListView.Items[i].SubItems[0].Text;
                    p.Description = CartListView.Items[i].SubItems[1].Text;
                    p.Price = Convert.ToDouble(CartListView.Items[i].SubItems[2].Text);
                    productList.Add(p);
                }
            }

            return productList;
        }

        private void TxtAmountPaid_TextChanged(object sender, EventArgs e)
        {
            if (TxtAmountPaid.Text != string.Empty)
            {
                if(Convert.ToDouble(TxtAmountPaid.Text) > Convert.ToDouble(LbTotal.Text)) 
                {
                    LbChange.Text = (Convert.ToDouble(TxtAmountPaid.Text) - Convert.ToDouble(LbTotal.Text)).ToString();
                }else
                {
                    LbChange.Text = "0";
                } 
            }

         }

        private void BtnClearCart_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem item in CartListView.Items)
            {
                item.Remove();
            }
            LbTotal.Text = "0";
            TxtAmountPaid.Text = "";
            LbChange.Text = "0";
        }
    }
}
