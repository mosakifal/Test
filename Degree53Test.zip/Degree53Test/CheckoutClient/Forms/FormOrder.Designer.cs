﻿namespace BrighthrTest
    {
    partial class FormOrder
        {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
            {
            if (disposing && (components != null))
                {
                components.Dispose();
                }
            base.Dispose(disposing);
            }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
            {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormOrder));
            this.Label11 = new System.Windows.Forms.Label();
            this.Label12 = new System.Windows.Forms.Label();
            this.LbChange = new System.Windows.Forms.Label();
            this.LbTotal = new System.Windows.Forms.Label();
            this.TxtAmountPaid = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.MonthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.BtnModify = new System.Windows.Forms.Button();
            this.CartListView = new System.Windows.Forms.ListView();
            this.BtnAddToCart = new System.Windows.Forms.Button();
            this.Label4 = new System.Windows.Forms.Label();
            this.Quantity = new System.Windows.Forms.NumericUpDown();
            this.Label3 = new System.Windows.Forms.Label();
            this.TxtPrice = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.CbProduct = new System.Windows.Forms.ComboBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.TableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.TableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)(this.Quantity)).BeginInit();
            this.SuspendLayout();
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.BackColor = System.Drawing.Color.Transparent;
            this.Label11.Location = new System.Drawing.Point(913, 256);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(48, 13);
            this.Label11.TabIndex = 63;
            this.Label11.Text = "Payment";
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.BackColor = System.Drawing.Color.Transparent;
            this.Label12.Location = new System.Drawing.Point(114, -13);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(33, 13);
            this.Label12.TabIndex = 33;
            this.Label12.Text = "Order";
            // 
            // LbChange
            // 
            this.LbChange.AutoSize = true;
            this.LbChange.BackColor = System.Drawing.Color.Transparent;
            this.LbChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.LbChange.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.LbChange.Location = new System.Drawing.Point(912, 390);
            this.LbChange.Name = "LbChange";
            this.LbChange.Size = new System.Drawing.Size(66, 20);
            this.LbChange.TabIndex = 56;
            this.LbChange.Text = "Change";
            // 
            // LbTotal
            // 
            this.LbTotal.AutoSize = true;
            this.LbTotal.BackColor = System.Drawing.Color.Transparent;
            this.LbTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.LbTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.LbTotal.Location = new System.Drawing.Point(912, 294);
            this.LbTotal.Name = "LbTotal";
            this.LbTotal.Size = new System.Drawing.Size(51, 20);
            this.LbTotal.TabIndex = 55;
            this.LbTotal.Text = "Total ";
            // 
            // TxtAmountPaid
            // 
            this.TxtAmountPaid.Location = new System.Drawing.Point(931, 345);
            this.TxtAmountPaid.Name = "TxtAmountPaid";
            this.TxtAmountPaid.Size = new System.Drawing.Size(126, 20);
            this.TxtAmountPaid.TabIndex = 54;
            this.TxtAmountPaid.TextChanged += new System.EventHandler(this.TxtAmountPaid_TextChanged);
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.BackColor = System.Drawing.Color.Transparent;
            this.Label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.Label9.Location = new System.Drawing.Point(812, 343);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(114, 20);
            this.Label9.TabIndex = 53;
            this.Label9.Text = "Amount Paid :";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.BackColor = System.Drawing.Color.Transparent;
            this.Label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.Label8.Location = new System.Drawing.Point(813, 390);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(76, 20);
            this.Label8.TabIndex = 52;
            this.Label8.Text = "Change :";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.BackColor = System.Drawing.Color.Transparent;
            this.Label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.Label7.Location = new System.Drawing.Point(811, 294);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(88, 20);
            this.Label7.TabIndex = 51;
            this.Label7.Text = "Total due :";
            // 
            // MonthCalendar1
            // 
            this.MonthCalendar1.Location = new System.Drawing.Point(839, 20);
            this.MonthCalendar1.Name = "MonthCalendar1";
            this.MonthCalendar1.TabIndex = 50;
            // 
            // BtnModify
            // 
            this.BtnModify.Location = new System.Drawing.Point(694, 469);
            this.BtnModify.Name = "BtnModify";
            this.BtnModify.Size = new System.Drawing.Size(75, 23);
            this.BtnModify.TabIndex = 48;
            this.BtnModify.Text = "Clear cart";
            this.BtnModify.UseVisualStyleBackColor = true;
            this.BtnModify.Click += new System.EventHandler(this.BtnClearCart_Click);
            // 
            // CartListView
            // 
            this.CartListView.FullRowSelect = true;
            this.CartListView.Location = new System.Drawing.Point(32, 263);
            this.CartListView.Name = "CartListView";
            this.CartListView.Size = new System.Drawing.Size(762, 191);
            this.CartListView.TabIndex = 41;
            this.CartListView.UseCompatibleStateImageBehavior = false;
            this.CartListView.View = System.Windows.Forms.View.Tile;
            // 
            // BtnAddToCart
            // 
            this.BtnAddToCart.Location = new System.Drawing.Point(49, 209);
            this.BtnAddToCart.Name = "BtnAddToCart";
            this.BtnAddToCart.Size = new System.Drawing.Size(139, 23);
            this.BtnAddToCart.TabIndex = 40;
            this.BtnAddToCart.Text = "Scan item";
            this.BtnAddToCart.UseVisualStyleBackColor = true;
            this.BtnAddToCart.Click += new System.EventHandler(this.BtnAddToCart_Click);
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.BackColor = System.Drawing.Color.Transparent;
            this.Label4.Location = new System.Drawing.Point(289, 142);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(46, 13);
            this.Label4.TabIndex = 39;
            this.Label4.Text = "Quantity";
            // 
            // Quantity
            // 
            this.Quantity.Location = new System.Drawing.Point(292, 161);
            this.Quantity.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.Quantity.Name = "Quantity";
            this.Quantity.Size = new System.Drawing.Size(86, 20);
            this.Quantity.TabIndex = 38;
            this.Quantity.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.BackColor = System.Drawing.Color.Transparent;
            this.Label3.Location = new System.Drawing.Point(49, 142);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(53, 13);
            this.Label3.TabIndex = 37;
            this.Label3.Text = "Unit Price";
            // 
            // TxtPrice
            // 
            this.TxtPrice.Location = new System.Drawing.Point(49, 161);
            this.TxtPrice.Name = "TxtPrice";
            this.TxtPrice.Size = new System.Drawing.Size(136, 20);
            this.TxtPrice.TabIndex = 36;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.Color.Transparent;
            this.Label2.Location = new System.Drawing.Point(49, 92);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(77, 13);
            this.Label2.TabIndex = 35;
            this.Label2.Text = "Select Product";
            // 
            // CbProduct
            // 
            this.CbProduct.FormattingEnabled = true;
            this.CbProduct.Location = new System.Drawing.Point(49, 110);
            this.CbProduct.Name = "CbProduct";
            this.CbProduct.Size = new System.Drawing.Size(200, 21);
            this.CbProduct.TabIndex = 34;
            this.CbProduct.SelectedIndexChanged += new System.EventHandler(this.CbProduct_SelectedIndexChanged);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.BackColor = System.Drawing.Color.Transparent;
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(70, 37);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(274, 29);
            this.Label1.TabIndex = 32;
            this.Label1.Text = "Degree 53 - Checkout ";
            this.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // TableLayoutPanel1
            // 
            this.TableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.TableLayoutPanel1.ColumnCount = 1;
            this.TableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.TableLayoutPanel1.Location = new System.Drawing.Point(32, 20);
            this.TableLayoutPanel1.Name = "TableLayoutPanel1";
            this.TableLayoutPanel1.RowCount = 1;
            this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.TableLayoutPanel1.Size = new System.Drawing.Size(357, 231);
            this.TableLayoutPanel1.TabIndex = 57;
            // 
            // TableLayoutPanel3
            // 
            this.TableLayoutPanel3.BackColor = System.Drawing.Color.Transparent;
            this.TableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.TableLayoutPanel3.ColumnCount = 1;
            this.TableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.TableLayoutPanel3.Location = new System.Drawing.Point(800, 263);
            this.TableLayoutPanel3.Name = "TableLayoutPanel3";
            this.TableLayoutPanel3.RowCount = 1;
            this.TableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.TableLayoutPanel3.Size = new System.Drawing.Size(266, 191);
            this.TableLayoutPanel3.TabIndex = 60;
            // 
            // FormOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1097, 514);
            this.Controls.Add(this.Label11);
            this.Controls.Add(this.Label12);
            this.Controls.Add(this.LbChange);
            this.Controls.Add(this.LbTotal);
            this.Controls.Add(this.TxtAmountPaid);
            this.Controls.Add(this.Label9);
            this.Controls.Add(this.Label8);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.MonthCalendar1);
            this.Controls.Add(this.BtnModify);
            this.Controls.Add(this.CartListView);
            this.Controls.Add(this.BtnAddToCart);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Quantity);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.TxtPrice);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.CbProduct);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.TableLayoutPanel1);
            this.Controls.Add(this.TableLayoutPanel3);
            this.Name = "FormOrder";
            this.Text = "FormOrder";
            this.Load += new System.EventHandler(this.FormOrder_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Quantity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

            }

        #endregion

        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.Label LbChange;
        internal System.Windows.Forms.Label LbTotal;
        internal System.Windows.Forms.TextBox TxtAmountPaid;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.MonthCalendar MonthCalendar1;
        internal System.Windows.Forms.Button BtnModify;
        internal System.Windows.Forms.ListView CartListView;
        internal System.Windows.Forms.Button BtnAddToCart;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.NumericUpDown Quantity;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox TxtPrice;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.ComboBox CbProduct;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TableLayoutPanel TableLayoutPanel1;
        internal System.Windows.Forms.TableLayoutPanel TableLayoutPanel3;
    }
    }