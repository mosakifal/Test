﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Data;
using System.Configuration;
using CheckoutClient.DataTransferObjects;

namespace BrighthrTest
{
    public class DataAccess
    {
        public List<Product> GetProductList()
        {
            DataTable table = new DataTable("Foods");
            table.Columns.Add("Sku");
            table.Columns.Add("Description");
            table.Columns.Add("Price");
            table.Rows.Add("A99", "Apple", 0.50);
            table.Rows.Add("B15", "Biscuits", 0.30);
            table.Rows.Add("C40", "Coffee", 1.80);
            table.Rows.Add("T23", "Tissues", 0.99);  
            DataSet ds = new DataSet();
            ds.Tables.Add(table);
            Product pl = new Product();
            return pl.FillFromDataSet(ds);
        }
    }
}
