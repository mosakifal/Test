﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace CheckoutClient.DataTransferObjects
{
    public class Product
    {
        public string Sku { get; set; }
        public string Description { get; set; }
        public double Price { get; set; }

        public List<Product> FillFromDataSet(DataSet ds)
        {
            List<Product> items = new List<Product>();
            if (ds != null && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    Product item = new Product();
                    item.Sku = row["Sku"].ToString();
                    item.Description = row["Description"].ToString();
                    item.Price = Convert.ToDouble(row["Price"]);
                    items.Add(item);
                }

            }
            return items;
        }

    }
}
