﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckoutService
{
    public class PricingRule
    {
        public string Sku { get; set; }
        public int ItemCount { get; set; }
        public double Total { get; set; }

        public PricingRule(string sku, int itemCount, double total)
        {
            this.Sku = sku;
            this.ItemCount = itemCount;
            this.Total = total;
        }

    }
}
