﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace CheckoutService
{
    [TestFixture]
    public class UnitTests
    {
        private ICheckout checkout;
        private SpecialOffer offer;

        [SetUp]
        public void SetUp()
        {
            offer = new SpecialOffer();
            checkout = new Checkout();
        }

        [Test]
        public void TestGettingPrincipleRules()
        {
            Assert.AreEqual(2, offer.GetPricingRules().Count());
        }

        [Test]
        public void TestTotalWithItemRuleA()
        {
            List<ProductItem> productList = new List<ProductItem>();
            ProductItem product1 = new ProductItem();
            product1.Sku = "A99";
            product1.Description = "Apple";
            product1.Price = 0.5;

            ProductItem product2 = new ProductItem();
            product2.Sku = "A99";
            product2.Description = "Apple";
            product2.Price = 0.5;

            ProductItem product3 = new ProductItem();
            product3.Sku = "A99";
            product3.Description = "Apple";
            product3.Price = 0.5;

            productList.Add(product1);
            productList.Add(product2);
            productList.Add(product3);
            double total = checkout.GetTotalPrice(productList);
            Assert.AreEqual(1.3, total);
        }

        [Test]
        public void TestTotalWithItemRuleB()
        {
            List<ProductItem> productList = new List<ProductItem>();
            ProductItem product1 = new ProductItem();
            product1.Sku = "B15";
            product1.Description = "Biscuits";
            product1.Price = 0.3;

            ProductItem product2 = new ProductItem();
            product2.Sku = "B15";
            product2.Description = "Biscuits";
            product2.Price = 0.3;

            productList.Add(product1);
            productList.Add(product2);
            double total = checkout.GetTotalPrice(productList);
            Assert.AreEqual(0.45, total);
        }

        [Test]
        public void TestTotalWithMultipleItemRuleB()
        {
            List<ProductItem> productList = new List<ProductItem>();
            ProductItem product1 = new ProductItem();
            product1.Sku = "B15";
            product1.Description = "Biscuits";
            product1.Price = 0.3;

            ProductItem product2 = new ProductItem();
            product2.Sku = "B15";
            product2.Description = "Biscuits";
            product2.Price = 0.3;

            ProductItem product3 = new ProductItem();
            product3.Sku = "B15";
            product3.Description = "Biscuits";
            product3.Price = 0.3;

            ProductItem product4 = new ProductItem();
            product4.Sku = "B15";
            product4.Description = "Biscuits";
            product4.Price = 0.3;

            productList.Add(product1);
            productList.Add(product2);
            productList.Add(product3);
            productList.Add(product4);
            double total = checkout.GetTotalPrice(productList);
            Assert.AreEqual(0.90, total);
        }

        [Test]
        public void TestTotalWithCombineRules()
        {
            List<ProductItem> productList = new List<ProductItem>();
            ProductItem product1 = new ProductItem();
            product1.Sku = "B15";
            product1.Description = "Biscuits";
            product1.Price = 0.3;

            ProductItem product2 = new ProductItem();
            product2.Sku = "B15";
            product2.Description = "Biscuits";
            product2.Price = 0.3;
            
            ProductItem product3 = new ProductItem();
            product3.Sku = "A99";
            product3.Description = "Apple";
            product3.Price = 0.5;

            ProductItem product4 = new ProductItem();
            product4.Sku = "A99";
            product4.Description = "Apple";
            product4.Price = 0.5;
            ProductItem product5 = new ProductItem();

            product5.Sku = "A99";
            product5.Description = "Apple";
            product5.Price = 0.5;

            productList.Add(product1);
            productList.Add(product2);
            productList.Add(product3);
            productList.Add(product4);
            productList.Add(product5);
            double total = checkout.GetTotalPrice(productList);
            Assert.AreEqual(1.75, total);
        }

        [Test]
        public void TestTotalWithoutRules()
        {
            List<ProductItem> productList = new List<ProductItem>();
            ProductItem product1 = new ProductItem();
            product1.Sku = "C40";
            product1.Description = "Coffe";
            product1.Price = 1.8;

            ProductItem product2 = new ProductItem();
            product2.Sku = "T23";
            product2.Description = "Tissues";
            product2.Price = 0.99;

            productList.Add(product1);
            productList.Add(product2);
            double total = checkout.GetTotalPrice(productList);
            Assert.AreEqual(2.79, total);
        }

        [Test]
        public void TestTotal()
        {
            List<ProductItem> productList = new List<ProductItem>();
            ProductItem product1 = new ProductItem();
            product1.Sku = "C40";
            product1.Description = "Coffee";
            product1.Price = 1.80;

            ProductItem product2 = new ProductItem();
            product2.Sku = "T23";
            product2.Description = "Tissues";
            product2.Price = 0.99;

            ProductItem product3 = new ProductItem();
            product3.Sku = "B15";
            product3.Description = "Biscuits";
            product3.Price = 0.3;

            ProductItem product4 = new ProductItem();
            product4.Sku = "B15";
            product4.Description = "Biscuits";
            product4.Price = 0.3;

            productList.Add(product1);
            productList.Add(product2);
            productList.Add(product3);
            productList.Add(product4);
            double total = checkout.GetTotalPrice(productList);
            Assert.AreEqual(3.24, total);
        }
    }
}
