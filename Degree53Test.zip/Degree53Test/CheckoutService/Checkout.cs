﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckoutService
{
    public class Checkout : ICheckout
    {
        private readonly SpecialOffer offer = new SpecialOffer();
        private List<PricingRule> pricingRules = new List<PricingRule>();

        public double GetTotalPrice(List<ProductItem> productList)
        {
            pricingRules = offer.GetPricingRules();

            var itemGroups = productList.GroupBy(x => x.Sku);

            double total = CalculateTotalPrice(itemGroups);
            return total;
        }

        private double CalculateTotalPrice(IEnumerable<IGrouping<string, ProductItem>> itemGroups)
        {
            double total = 0;
            foreach (var itemGroup in itemGroups)
            {
                total += TotalPricePerGroup(itemGroup);
            }

            return total;
        }

        private double TotalPricePerGroup(IGrouping<string, ProductItem> itemGroup)
        {
            double total = 0;
            var ruleForGroup = pricingRules.FirstOrDefault(x => x.Sku == itemGroup.Key);

            if (ruleForGroup != null)
            {
                total = ApplyRule(itemGroup, ruleForGroup);
            }
            else
            {
                total += itemGroup.Sum(x => x.Price);
            }

            return total;
        }

        private double ApplyRule(IGrouping<string, ProductItem> itemGroup, PricingRule ruleForGroup)
        {
            double total = 0;
            int count = 0;
            var extra = itemGroup.Count();
            while (extra >= ruleForGroup.ItemCount)
            {
                total += ruleForGroup.Total;
                extra -= ruleForGroup.ItemCount;
            }

            if (extra > 0)
            {
                total += extra * itemGroup.First().Price;
            }

            return total;
        }
    }
}
