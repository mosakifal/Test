﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckoutService
{
    public class SpecialOffer
    {
        public SpecialOffer(){}

        public List<PricingRule> GetPricingRules()
        {
            List<PricingRule> rules = new List<PricingRule>();

            PricingRule ItemA99Rule = new PricingRule("A99", 3, 1.30);
            PricingRule ItemB15Rule = new PricingRule("B15", 2, 0.45);

            rules.Add(ItemA99Rule);
            rules.Add(ItemB15Rule);
            return rules;
        }
    }
}
