Checkout test. 

I create this app using two projects :  
	a CheckoutClient project where the UI is a windows form
	a CheckoutService project which deals with the calcuation of the total based on the items in the basket 

To run the application the CheckoutClient project needs to be setup as startup project

The test the application please follow the bellow steps :
	Select a product from 
	Select a quantity
	Press Scan item button which adds the item to the cart below
	
	the total is automatically calculated each time an item is added to the cart and based on special offer applicable

	To clear items in the cart :
		 Press the Clear Cart in the cart
